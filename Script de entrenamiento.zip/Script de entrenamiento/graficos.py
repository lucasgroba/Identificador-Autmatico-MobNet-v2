import pandas as pd
import matplotlib.pyplot as plt


def plot_csv_columns(data_dir, name):
    # Cargar el archivo CSV
    df = pd.read_csv(data_dir)

    # Obtener el número de columnas
    num_columns = len(df.columns)

    # Graficar cada columna en un gráfico separado
    for i in range(num_columns):
        column_name = df.columns[i]
        plt.plot(df.index, df[column_name])
        plt.title(column_name)  # Utiliza el nombre de la columna como título
        plt.xlabel('Época')
        plt.ylabel('Valor')
        plt.savefig(f"{data_dir}_{column_name}.png")
        plt.clf()  # Limpiar la figura para la siguiente iteración


