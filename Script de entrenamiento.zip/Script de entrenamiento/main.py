import keras.metrics
import numpy as np
import tensorflow as tf
from keras.applications import MobileNetV2
from keras.callbacks import CSVLogger, EarlyStopping ,ModelCheckpoint
from keras.engine.input_layer import Input
from datetime import datetime
from tensorflow.keras.applications import MobileNetV3Small
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout, BatchNormalization
from Utilities import *
from graficos import *
from tensorflow.keras import optimizers, Input
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, f1_score
from tensorflow.keras import backend as Kv

if tf.config.list_physical_devices('GPU'):
    device = "/GPU:0"
else:
    device = "/CPU:0"

# Ruta del DataSet
    dataset_path = '/home/usuario/DataSet/'
    model_dir = '/home/usuario/PycharmProjects/pythonProject/venv/Models/MobileNet-v2'
    data_dir = '/home/usuario/PycharmProjects/pythonProject/venv/Scripts/excel/MobileNet-v2/entrenamiento_'+str(datetime.now())+'.csv'
    batch_size= 32


# DataAugmentation
    data = ImageDataGenerator(
        rescale=1./255,
        rotation_range=10,
        width_shift_range=0.1,
        height_shift_range=0.1
        #shear_range=0.2,
        #zoom_range=0.0,
        #horizontal_flip=False,
        #fill_mode='nearest'
    )

traindata = data.flow_from_directory(
        dataset_path+"train",
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='categorical',
        shuffle = True,
        color_mode='rgb'
    )
validationdata= data.flow_from_directory(
        dataset_path+"val",
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='categorical',
        shuffle = True,
        color_mode='rgb'
    )
testdata= data.flow_from_directory(
        dataset_path+"test",
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='categorical',
        shuffle = True,
        color_mode='rgb'
    )


with tf.device(device):
    # Cargo el modelo MobileNetV3 preentrenado
    base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
    num_classes = 19

    # Congelo las capas del modelo base
    base_model.trainable = False

    #Personalizo las capas del modelo
    inputs = Input(shape = (224,224,3))
    x = base_model(inputs, training = False)
    x = GlobalAveragePooling2D()(x)
    x = Dropout(0.3)(x)
    x = BatchNormalization()(x)
    x = Dense(1024, activation='relu')(x)
    x = Dropout(0.3)(x)
    x = BatchNormalization()(x)
    x = Dense(1024, activation='relu')(x)
    x = Dropout(0.3)(x)
    x = BatchNormalization()(x)
    x = Dense(512, activation='relu')(x)
    x = Dropout(0.2)(x)
    x = BatchNormalization()(x)
    x = Dense(512, activation='relu')(x)

    outputs= Dense(num_classes, activation='softmax')(x)
    model = Model(inputs=inputs, outputs=outputs)





    #Create Callbacks

    checkpoint = ModelCheckpoint(model_dir,
                                 verbose=1,
                                 save_best_only = True,
                                 monitor = 'val_f1_m',
                                 save_weights_only = False,
                                 mode = 'max')

    # Definir EarlyStopping
    early = EarlyStopping(monitor='val_f1_m', patience=10, mode='max' )

    # Definir el archivo CSV para guardar los logs
    csv_logger = CSVLogger(data_dir, append=True, separator=',')

    stepsTrain = (traindata.n // batch_size)
    stepsVal = (validationdata.n // batch_size)

    lr_schedule = optimizers.schedules.ExponentialDecay(0.0001,
                                                        decay_steps=stepsTrain * 2,
                                                        decay_rate=0.9)

    model.compile(optimizer=optimizers.SGD(learning_rate=lr_schedule, momentum=0.9, nesterov=True),
                  loss="categorical_crossentropy", metrics=['acc', f1_m])

    # Entrenar el modelo
    model.fit(traindata, epochs=150,
              callbacks=[checkpoint, csv_logger, early],
              validation_data=validationdata,
              steps_per_epoch=stepsTrain, validation_steps=stepsVal)

    test_loss, test_accuracy, test_f1 = model.evaluate(validationdata)
    print(f'Pérdida en el conjunto de prueba: {test_loss}')
    print(f'Precisión en el conjunto de prueba: {test_accuracy}')
    print(f'F1 en el conjunto de prueba: {test_f1}')
    test_loss, test_accuracy, test_f1 = model.evaluate(testdata)
    print(f'Pérdida en el conjunto de prueba: {test_loss}')
    print(f'Precisión en el conjunto de prueba: {test_accuracy}')
    print(f'F1 en el conjunto de prueba: {test_f1}')

    # Predicciones y clasificación de informes en el conjunto de validación
    #validationdata.reset()
    y_val_true = validationdata.classes
    y_val_pred_prob = model.predict(validationdata)
    y_val_pred = np.argmax(y_val_pred_prob, axis=1)

    # Generar el informe de clasificación para el conjunto de validación
    print('Informe de clasificación para el conjunto de validación:')
    print(classification_report(y_val_true, y_val_pred, target_names=validationdata.class_indices.keys(),zero_division=0))

    # Predicciones y clasificación de informes en el conjunto de prueba
    #testdata.reset()
    y_test_true = testdata.classes
    y_test_pred_prob = model.predict(testdata)
    y_test_pred = np.argmax(y_test_pred_prob, axis=1)

    # Generar el informe de clasificación para el conjunto de prueba
    print('Informe de clasificación para el conjunto de prueba:')
    print(classification_report(y_test_true, y_test_pred, target_names=testdata.class_indices.keys(),zero_division=0))

    # Graficar la función de pérdida, la precisión y la F1
    plt.figure(figsize=(18, 5))

    print("El modelo MobileNet v3 ha sido reentrenado")
    print("Generando graficos del entrenamiento del modelo")

    plot_csv_columns(data_dir, 'Graficos del entrenamiento del modelo')


