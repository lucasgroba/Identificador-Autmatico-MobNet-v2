from keras.applications import MobileNetV3Small
from tensorflow.keras.layers import Dense, BatchNormalization, GlobalAveragePooling2D, Dropout, LeakyReLU
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2
from tensorflow.keras import backend as K
from tensorflow.keras.models import Model
from tensorflow.keras import optimizers, Input
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger
from cusom_objects import *
from datetime import datetime
import matplotlib.pyplot as plt
from graficos import *


dataset_dir = '/home/usuario/DataSet/'

model_dir = '/home/usuario/PycharmProjects/pythonProject/venv/Models/MobNet-v2'
data_dir = '/home/usuario/PycharmProjects/pythonProject/venv/Scripts/excel/MobNet-v2/entrenamiento_'+str(datetime.now())+'.csv'

batch_size = 64

data = ImageDataGenerator(rescale=1./ 255,
                         rotation_range=40,
        height_shift_range=0.2,
        width_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        vertical_flip=True,
        fill_mode='nearest')



traindata = data.flow_from_directory(directory=dataset_dir+"train",
                                     target_size=(224, 224),
                                     batch_size=batch_size,
                                     class_mode='categorical',
                                     shuffle=True)

validationdata = data.flow_from_directory(directory=dataset_dir+"val",
                                          target_size=(224, 224),
                                          batch_size=batch_size,
                                          class_mode='categorical',
                                          shuffle=False)


mobNet = MobileNetV2(include_top=False, weights='imagenet', input_shape=(224, 224, 3))
mobNet.trainable = False

inputs = Input(shape=(224, 224, 3))
x = mobNet(inputs, training=False)
x = GlobalAveragePooling2D()(x)
x = Dropout(0.3)(x)
x = BatchNormalization()(x)
x = Dense(1024, activation='relu')(x)
x = Dropout(0.3)(x)
x = BatchNormalization()(x)
x = Dense(1024, activation='relu')(x)
x = Dropout(0.3)(x)
x = BatchNormalization()(x)
x = Dense(1024, activation='relu')(x)
x = Dropout(0.3)(x)
x = BatchNormalization()(x)
x = Dense(1024, activation='relu')(x)
x = Dropout(0.3)(x)
x = BatchNormalization()(x)
x = Dense(512, activation='relu')(x)
x = Dropout(0.3)(x)
x = BatchNormalization()(x)
x = Dense(512, activation='relu')(x)
x = Dropout(0.3)(x)
outputs = Dense(traindata.num_classes, activation='softmax')(x)
model = Model(inputs, outputs)


checkpoint = ModelCheckpoint(model_dir,
                             verbose=1,
                             save_best_only=True,
                             monitor='val_f1_m',
                             save_weights_only=False,
                             mode='max')

early = EarlyStopping(monitor='val_f1_m', patience=10, mode = 'max')

csv_logger = CSVLogger(data_dir, append=True, separator=',')


stepsTrain = (traindata.n // batch_size)
stepsVal = (validationdata.n // batch_size)


lr_schedule = optimizers.schedules.ExponentialDecay(0.1,
                                                    decay_steps=stepsTrain*2,
                                                    decay_rate=0.9)


model.compile(optimizer=optimizers.SGD(learning_rate=lr_schedule, momentum=0.9, nesterov=True),
              loss="categorical_crossentropy", metrics=['acc', f1_m])


model.fit(traindata, epochs=100,
          callbacks=[checkpoint, csv_logger, early],
          validation_data=validationdata,
          steps_per_epoch=stepsTrain, validation_steps=stepsVal)
model.save('MobNet-v2Desbalanceado.h5')

test_dir = '/home/usuario/DataSet/test'

data = ImageDataGenerator(rescale=1./255)
testdata = data.flow_from_directory(directory = test_dir,
                                   target_size = (224,224),
                                   batch_size = batch_size,
                                   class_mode = 'categorical',
                                   shuffle = False)

names = list(testdata.class_indices.keys())




import numpy as np
from sklearn.metrics import classification_report, accuracy_score

Y_pred = model.predict(testdata,steps = testdata.n/batch_size)[:, :18]
y_pred = np.argmax(Y_pred, axis=1)

print('Classification Report')
print(classification_report(testdata.classes, y_pred, target_names=names))
print('Accuracy test(Predict):{0}'.format(accuracy_score(testdata.classes,y_pred)))

plt.figure(figsize=(18, 5))
plot_csv_columns(data_dir, 'Graficos del entrenamiento del modelo')