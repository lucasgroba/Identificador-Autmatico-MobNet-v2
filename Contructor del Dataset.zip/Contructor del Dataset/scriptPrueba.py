import cv2
from datetime import datetime
import RPi.GPIO as GPIO
import time

def measure_distance(trigger_pin, echo_pin):
    # Configurar pines GPIO
    GPIO.setup(trigger_pin, GPIO.OUT)
    GPIO.setup(echo_pin, GPIO.IN)

    # Generar un pulso corto en el pin de trigger para iniciar la medición
    print('Generando Pulso')
    GPIO.output(trigger_pin, GPIO.LOW)
    time.sleep(0.5)
    GPIO.output(trigger_pin, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(trigger_pin, GPIO.LOW)

    # Medir el tiempo que tarda en llegar el eco
    while GPIO.input(echo_pin) == GPIO.LOW:
        pulse_start = time.time()

    while GPIO.input(echo_pin) == GPIO.HIGH:
        pulse_end = time.time()

    # Calcular la duración del pulso y convertir a distancia en centímetros
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150  # La velocidad del sonido es de aproximadamente 343 m/s
    distance = round(distance, 2)

    return distance

def capture_on_object_detection(camera_index=0, photo_path='captured_photo.jpg', trigger_pin=23, echo_pin=24, threshold_distance=20):

     # Configurar la GPIO
    GPIO.setmode(GPIO.BCM)
    
    # Establecer el estado anterior como no detectado
    previous_detection = False
    print('Entre a la funcion ')

    try:
        while True:
            #Inicializo la camara
            cap = cv2.VideoCapture(camera_index)
            # Medir la distancia
            distance = measure_distance(trigger_pin, echo_pin)
            #print('Midiendo Distancia: '+str(distance))

            # Verificar el cambio en la detección de objetos
            current_detection = distance < threshold_distance

            # Si cambia de no detectado a detectado, capturar una foto
            if not previous_detection and current_detection:
                
                time.sleep(2)
                # Guardar la imagen capturada en un archivo                
                ret, frame = cap.read()
                cv2.imwrite(photo_path+str(datetime.now())+'.jpg', frame)
                print(f"Foto capturada y guardada en {photo_path+str(datetime.now())+'.jpg'}")

            # Actualizar el estado anterior
            previous_detection = current_detection

            # Esperar un tiempo antes de la siguiente verificación
            time.sleep(0.1)
                
            
            #Libero la camara    
            cap.release()
            
            
            
            


    except KeyboardInterrupt:
        pass
    finally:
        # Liberar la cámara y limpiar la configuración de la GPIO al salir
        cap.release()
        cv2.destroyAllWindows()
        GPIO.cleanup()



            

    

if __name__ == "__main__":
    
    # Especificar el índice de la cámara y la ruta donde se guardará la foto capturada
    camera_index = 0
    photo_path = '/home/impac/Desktop/ColectorDataSet/capturas/captured_'
    trigger_pin = 23  # Ajusta los pines según tu configuración
    echo_pin = 24  # Ajusta los pines según tu configuración
    threshold_distance = 40 #Umbral de distancia en centímetros

    


    # Capturar la foto cuando se detecte que el sensor tiene un pallet delante.
    capture_on_object_detection(camera_index, photo_path, trigger_pin, echo_pin, threshold_distance)

